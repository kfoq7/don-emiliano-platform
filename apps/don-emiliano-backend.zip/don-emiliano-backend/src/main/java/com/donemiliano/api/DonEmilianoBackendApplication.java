package com.donemiliano.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonEmilianoBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonEmilianoBackendApplication.class, args);
	}

}
